#include "edgetree.h"
#include "changestat.h"

D_CHANGESTAT_FN(d_coincidence);
